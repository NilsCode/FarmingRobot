# -*- coding: utf-8 -*-
"""
Created on Tue Apr  2 22:15:50 2019

@author: Nilesh
"""

#!flask/bin/python
from app import app
import threading 

app.run(debug=True)

